#!/bin/bash

source ./../shared/api_request.sh
source ./../shared/validation.sh
